package com.example.proyectokotlinylosciclos

import kotlin.math.pow

// Nombre:
// Fecha:
// Descripción: Solución del Problema 7 de la guía de Kotlin y los ciclos

// Función principal
fun main() {
    problema7()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema7() {
    // Desarrolle aquí la lógica
    println("N:")
    val N = readln().toInt()
    if (N <= 0){
        println("Error")
    }else{
        var resultado = 0
        for (i in 1..N){
            var n = i.toDouble()
            resultado = (resultado + n.pow(3.0)).toInt()
        }
        println("s = $resultado")
    }


}