package com.example.proyectokotlinylosciclos

// Nombre:
// Fecha:
// Descripción: Solución del Problema 4 de la guía de Kotlin y los ciclos

// Función principal
fun main() {
    problema4()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema4() {
    println("n:")
    var n = readln().toInt()
    var i = 0
    var i_max = i
    var maxnum = -9999999
    while (n != 0){
        i++
        if (n > maxnum){
            maxnum = n
            i_max = i
        }
        println("n:")
        n = readln().toInt()
    }
    println("Posición del mayor = $i_max")
}