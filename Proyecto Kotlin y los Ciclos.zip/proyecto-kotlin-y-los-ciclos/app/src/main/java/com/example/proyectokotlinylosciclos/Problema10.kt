package com.example.proyectokotlinylosciclos

// Nombre:
// Fecha:
// Descripción: Solución del Problema 10 de la guía de Kotlin y los ciclos

// Función principal
fun main() {
    problema10()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema10() {
    // Desarrolle aquí la lógica
    println("n:")
    val n = readln().toInt()
    var cadena = ""
    if (n in 1..9){
        for (i in 1..n){
            cadena += "$i"
            println(cadena)
        }
    }else{
        println("Error")
    }
}