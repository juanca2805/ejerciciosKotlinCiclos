package com.example.proyectokotlinylosciclos

// Nombre:
// Fecha:
// Descripción: Solución del Problema 2 de la guía de Kotlin y los ciclos

// Función principal
fun main() {
    problema2()
}

// Calcula el número de días necesarios para que finalmente alcances la distancia requerida
// para el evento, si aumentas tu distancia cada día en un 10% con respecto al día anterior.
fun problema2() {
    val x = 10.0 //DISTANCIA INICIAL EN KM
    val y = 20.0 //DISTANCIA OBJETIVO EN KM
    var distance = x
    var days = 1

    while (distance < y) {
        distance += distance * 0.1  // Incrementa la distancia en un 10%
        days++
    }

    println(days) // DIAS NECESARIOS PARA RECORRER LA DISTANCIA

}