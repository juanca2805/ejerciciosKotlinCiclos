package com.example.proyectokotlinylosciclos

// Nombre:Juan Camilo Pedraza Sandoval
// Fecha:16/08/2024
// Descripción: Solución del Problema 1 de la guía de Kotlin y los ciclos

// Función principal
fun main() {
    problema1()
}

// imprima todos los cuadrados de los números enteros donde el cuadrado es menor o igual
// que N, en orden ascendente.
fun problema1() {
    // Desarrolle aquí la lógica
    val N = 50  // Valor límite
    var i = 1   // Número inicial

    while (i * i <= N) {
        println(i * i)  // Imprime el cuadrado de i
        i++
    }
    }
